# What is this ?
This software was made to help artist train with quick sketch.
This software allow you to display a random image taken from a folder you (the user) selected with a specified time sequence (by the user), for exemple :

Show a random image for 30sec then hide it for 30sec and show a new one for 30 sec... Repeat until "stop" is clicked.

# How to install ?
For windows you can download the zip file LookArtWindowsVer and extract it into a folder.

For Mac and Linux : install Visual Studio and generate it to get the executable for your OS.

# Licence & credits
**Please refer to the LICENCE.md file for the licence.**
